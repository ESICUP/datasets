Instances are grouped by class to run them consecutively (e.g. A_W500H1000I50)
Raw files are stored in a folder for unweighted problems and in p folder for weighted problems.
A instance file is decomposed as follows:
	- first raw: bin width, bin height, number of items to cut
	- one raw for each item: item width, item height, item profit, item demand

