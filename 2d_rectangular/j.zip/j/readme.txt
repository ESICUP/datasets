Description: 
2D Rectangular Strip Packing Problems (J) from JAKOBS (1996)
This file contains two test problems from Jakobs (1996)
(Data sets: j1, j2)

References: 
Jakobs S., 1996, On genetic algorithms for the packing of polygons, European Journal of Operational Research 88, 165-181.