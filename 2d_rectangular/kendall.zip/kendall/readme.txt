Description: 
2D Rectangular Strip Packing Problems (KENDALL) from BURKE/KENDALL (1999)
This file contains a test problem from Burke (1999).
(Data set: kendall)

References: 
Burke E. and Kendall G., 1999. Applying Simulated Annealing and the No Fit Polygon to the Nesting Problem. 
Proceedings of the World Manufacturing Congress, Durham, UK, pp. 27-30. 