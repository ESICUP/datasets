Description: 
2D Assortment test problems (ASSORT) from BEASLEY (1985)
These data files are the 12 test problems from Table 1 of Beasley (1985). Heuristic solution values are given in the above paper. 
The optimal solution values are not known at present.
(Data sets: assort1, assort2, ..., assort12)

References: 
J.E.Beasley, "An algorithm for the two-dimensional assortment problem" European Journal of Operational Research 19 (1985) 253-261.
(Also available from ORLib under: Two-dimensional cutting/packing - assortment problem at: http://mscmga.ms.ic.ac.uk/info.html ) 